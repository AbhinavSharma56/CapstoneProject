// user-profile.component.ts
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UserProfileService } from '../../../services/user-profile.service';

interface UserProfile {
  username: string;
  fullName: string;
  dob: string;
  email: string;
  mobileNumber: string;
  gender: string;
  address: string;
  weight: number | null;
  height: number | null;
}

@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css'],
})
export class UserProfileComponent implements OnInit {
  userProfileObj: UserProfile = {
    username: '',
    fullName: '',
    dob: '',
    email: '',
    mobileNumber: '',
    gender: '',
    address: '',
    weight: null,
    height: null,
  };
  isSubmitting = false;

  constructor(private userProfileService: UserProfileService) {}

  ngOnInit(): void {
    // 1) Try loading entire profile blob first
    const stored = localStorage.getItem('userProfile');
    if (stored) {
      this.userProfileObj = JSON.parse(stored);
      return;
    }

    // 2) Otherwise attempt API fetch using whatever you stored as "loggedUser"
    const raw = localStorage.getItem('loggedUser');
    let username = '';
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        username = parsed.username || parsed.email || parsed;
      } catch {
        username = raw;
      }
    }

    if (!username) {
      console.warn('No loggedUser in localStorage; form will remain empty.');
      return;
    }

    this.userProfileService.getUserProfile(username).subscribe(
      (res) => {
        const data = (res as any).data || res;
        this.userProfileObj = data;
        localStorage.setItem('userProfile', JSON.stringify(data));
      },
      (err) => {
        console.error('Error fetching user profile:', err);
        this.loadProfileFromLocalStorage();
      }
    );
  }

  loadProfileFromLocalStorage() {
    // fallback: pull each field individually
    this.userProfileObj.username   = localStorage.getItem('username')   || this.userProfileObj.username;
    this.userProfileObj.fullName   = localStorage.getItem('fullName')   || this.userProfileObj.fullName;
    this.userProfileObj.dob        = localStorage.getItem('dob')        || this.userProfileObj.dob;
    this.userProfileObj.email      = localStorage.getItem('email')      || this.userProfileObj.email;
    this.userProfileObj.mobileNumber = localStorage.getItem('mobileNumber') || this.userProfileObj.mobileNumber;
    this.userProfileObj.gender     = localStorage.getItem('gender')     || this.userProfileObj.gender;
    this.userProfileObj.address    = localStorage.getItem('address')    || this.userProfileObj.address;
    this.userProfileObj.weight     = this.parseNum(localStorage.getItem('weight'));
    this.userProfileObj.height     = this.parseNum(localStorage.getItem('height'));
  }

  parseNum(v: string | null): number | null {
    const n = Number(v);
    return isNaN(n) ? null : n;
  }

  onSubmit() {
    this.isSubmitting = true;
    this.userProfileService.updateUserProfile(this.userProfileObj).subscribe(
      (res) => {
        console.log('Profile updated successfully:', res);
        // re-cache the updated profile
        localStorage.setItem('userProfile', JSON.stringify(this.userProfileObj));
        this.isSubmitting = false;
      },
      (err) => {
        console.error('Error updating profile:', err);
        this.isSubmitting = false;
      }
    );
  }

  resetForm() {
    // reload either from API or localStorage
    this.ngOnInit();
  }
}
