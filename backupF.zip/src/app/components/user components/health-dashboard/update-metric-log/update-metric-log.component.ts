import { Component } from '@angular/core';

@Component({
  selector: 'app-update-metric-log',
  standalone: true,
  imports: [],
  templateUrl: './update-metric-log.component.html',
  styleUrl: './update-metric-log.component.css'
})
export class UpdateMetricLogComponent {

}
