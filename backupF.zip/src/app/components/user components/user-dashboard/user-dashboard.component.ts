import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {
  // ← declare it here:
  public phrases: string[] = [
    'Hit Your Fitness Goals',
    'Track Your Nutrition',
    'Balance Your Mind'
  ];
  public currentText: string = '';        // ← this was missing
  private phraseIndex: number = 0;
  private charIndex: number = 0;
  private typingSpeed: number = 100;      // ms per character
  private pauseDelay: number = 2000;      // pause at full phrase

  ngOnInit(): void {
    this.typeNext();
  }

  private typeNext(): void {
    const full = this.phrases[this.phraseIndex];
    if (this.charIndex < full.length) {
      this.currentText += full.charAt(this.charIndex++);
      setTimeout(() => this.typeNext(), this.typingSpeed);
    } else {
      setTimeout(() => this.erase(), this.pauseDelay);
    }
  }

  private erase(): void {
    if (this.charIndex > 0) {
      this.currentText = this.currentText.slice(0, -1);
      this.charIndex--;
      setTimeout(() => this.erase(), this.typingSpeed / 2);
    } else {
      this.phraseIndex = (this.phraseIndex + 1) % this.phrases.length;
      setTimeout(() => this.typeNext(), this.typingSpeed);
    }
  }
}
