import { Component, AfterViewInit, ViewChild, ElementRef } from '@angular/core';

import { AboutComponent } from '../about/about.component';

import { RouterLink } from '@angular/router';

@Component({

 selector: 'app-home',

 standalone: true,

 imports: [AboutComponent, RouterLink],

 templateUrl: './home.component.html',

 styleUrls: ['./home.component.css']

})

export class HomeComponent implements AfterViewInit {

 @ViewChild('balanceText', { static: true }) balanceEl!: ElementRef<HTMLSpanElement>;

 // 1. Define the list of words to cycle through

 private words = ['BalanceIQ', 'Body', 'Mind', 'Meals'];

 private typingSpeed = 150; // ms per character

 private erasingSpeed = 75; // ms per character when erasing

 private pauseAfterType = 2000; // ms to wait after typing a word before erasing

 private pauseBeforeType = 500; // ms to wait after erasing before typing next

 private wordIndex = 0;

 private charIndex = 0;

 ngAfterViewInit(): void {

  this.startTypingLoop();

 }

 /** Kick off the typing↔erasing cycle */

 private startTypingLoop(): void {

  this.typeNextCharacter();

 }

 /** Type characters one by one */

 private typeNextCharacter(): void {

  const currentWord = this.words[this.wordIndex];

  if (this.charIndex < currentWord.length) {

   this.balanceEl.nativeElement.textContent += currentWord.charAt(this.charIndex);

   this.charIndex++;

   setTimeout(() => this.typeNextCharacter(), this.typingSpeed);

  } else {

   // Word fully typed → pause, then start erasing

   setTimeout(() => this.eraseNextCharacter(), this.pauseAfterType);

  }

 }

 /** Erase characters one by one */

 private eraseNextCharacter(): void {

  if (this.charIndex > 0) {

   const currentWord = this.words[this.wordIndex];

   this.balanceEl.nativeElement.textContent = currentWord.substring(0, this.charIndex - 1);

   this.charIndex--;

   setTimeout(() => this.eraseNextCharacter(), this.erasingSpeed);

  } else {

   // Fully erased → advance to next word and restart typing

   this.wordIndex = (this.wordIndex + 1) % this.words.length;

   setTimeout(() => this.typeNextCharacter(), this.pauseBeforeType);

  }

 }

 scrollToAbout(): void {

  const aboutSection = document.getElementById('about');

  if (aboutSection) aboutSection.scrollIntoView({ behavior: 'smooth' });

 }

}
