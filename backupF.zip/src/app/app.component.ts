import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ExerciseDashboardComponent } from "./components/user components/exercise-dashboard/exercise-dashboard.component";
import { HealthDashboardComponent } from "./components/user components/health-dashboard/health-dashboard.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, ExerciseDashboardComponent, HealthDashboardComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
}
